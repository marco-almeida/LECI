% initializes a vector with n size and fills it with 0s
function vector = init_vector(n)
    vector = zeros(1,n);
end